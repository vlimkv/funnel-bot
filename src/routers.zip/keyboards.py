# src/keyboards.py
import os
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from .config import Config
from .texts import (
    SIREN_YOUTUBE_URL, SIREN_YOUTUBE_BTN,
    SIREN_PRESALE_FORM_URL, SIREN_PRESALE_BTN
)

def main_kb() -> InlineKeyboardMarkup:
    """Главная клавиатура (без 'лист ожидания')"""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎥 Снова на YouTube", url=Config.YOUTUBE_URL)],
        [InlineKeyboardButton(text="📱 Instagram", url=os.getenv("INSTAGRAM_URL","https://instagram.com"))],
    ])

def contact_kb() -> InlineKeyboardMarkup:
    # Оставляем как есть — используется в текстовом flow «Контакт»
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏭ Пропустить", callback_data="skip_contact")]
    ])

# --- Новые клавиатуры для SIREN-флоу ---

def siren_youtube_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=SIREN_YOUTUBE_BTN, url=SIREN_YOUTUBE_URL)],
        [InlineKeyboardButton(text="📱 Instagram", url=os.getenv("INSTAGRAM_URL","https://instagram.com"))],
    ])

def siren_presale_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=SIREN_PRESALE_BTN, url=SIREN_PRESALE_FORM_URL)],
        [InlineKeyboardButton(text="📱 Instagram", url=os.getenv("INSTAGRAM_URL","https://instagram.com"))],
    ])